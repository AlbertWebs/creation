<div class="instagram-section section">
    <div class="wrap">
        <div class="wrap_float instagram-posts-list grid" id="instagram-posts">
            <div class="instagram-post-item">
                <img src="{{asset('theme/blog/img/inst-1.jpg')}}" alt="">
            </div>
            <div class="instagram-post-item">
                <img src="{{asset('theme/blog/img/inst-2.jpg')}}" alt="">
            </div>
            <div class="instagram-post-item">
                <img src="{{asset('theme/blog/img/inst-3.jpg')}}" alt="">
            </div>
            <div class="instagram-post-item">
                <img src="{{asset('theme/blog/img/inst-4.jpg')}}" alt="">
            </div>
            <div class="instagram-post-item">
                <img src="{{asset('theme/blog/img/inst-5.jpg')}}" alt="">
            </div>
            <div class="instagram-post-item">
                <img src="{{asset('theme/blog/img/inst-6.jpg')}}" alt="">
            </div>
            <div class="instagram-post-item">
                <img src="{{asset('theme/blog/img/inst-7.jpg')}}" alt="">
            </div>
        </div>
    </div>
 </div>